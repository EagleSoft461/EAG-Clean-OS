LANGUAGE TR: Herkeze selam ben eagle bu benim python dili ile oluşturduğum bir cleaner uygulaması umarım bu uygulamanın gelişmesine katkı sağlarsınız :)
__________________________________________________________________________________________________________________________________________________________________________
LANGUAGE EN:Hello everyone, I'm eagle, this is a cleaner application I created with Python language. I hope you will contribute to the development of this application :)
__________________________________________________________________________________________________________________________________________________________________________
LANGUAGE RU:Привет всем, я орел, это более чистое приложение, которое я создал на языке Python. Надеюсь, вы внесете свой вклад в разработку этого приложения :)
_______________________________________________________________________________________________________________________________________________________________
LANGUAGE ja: 皆さんこんにちは、私はワシです。これは私が Python 言語で作成したよりクリーンなアプリケーションです。このアプリケーションの開発に貢献していただければ幸いです :)

⚙️Özellikler/FEATURES
----------------------
Log kaydı/Log save ✅
Zamanlanmış görevler/Scheduled tasks ✅
Zamanlayıcıyı sürekli çalıştırma (Arka planda)/Continuously running the timer (In the background) ✅
------------------------------------------------------------------------------------------------------

🛠️Kullanılan kütüphaneler/Libraries used
-----------------------------------------
shutil ✅
tkinter ✅
schedule ✅
hashlib ✅
-----------------------------------------
