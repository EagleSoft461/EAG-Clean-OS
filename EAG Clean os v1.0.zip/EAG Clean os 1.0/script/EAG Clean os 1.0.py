import os
import shutil
import time
from tkinter import *
from tkinter import messagebox, filedialog, ttk
from datetime import datetime
import schedule
import logging
import threading  # threading modülünü ekliyoruz
import hashlib

# Lisans anahtarının hashlenmiş hali (gerçek anahtar daha karmaşık olabilir)
valid_license_hash = "e99a18c428cb38d5f260853678922e03"  # lisans anahtarı

def validate_license(user_input):
    # Kullanıcının girdiği anahtarı hash'le ve geçerli anahtar ile karşılaştır
    user_input_hash = hashlib.md5(user_input.encode()).hexdigest()
    return user_input_hash == valid_license_hash

def main():
    # Kullanıcıdan lisans anahtarını al
    user_input = input("Lisans anahtarını girin: ")
    
    if validate_license(user_input):
        print("Lisans anahtarı geçerli. Uygulama başlatılıyor...")
        
    else:
        print("Geçersiz lisans anahtarı!")
        exit()

if __name__ == "__main__":
    main()

        # Log kaydı ayarlama
logging.basicConfig(filename='backup_cleanup_log.txt', level=logging.INFO, format='%(asctime)s - %(message)s')

# Ana pencere
root = Tk()
root.title("Veri Yedekleme ve Temizleme")
root.geometry("700x700")  # Pencere boyutunu büyütme

# Geçici dosyalar için dizinler
temp_directories = [
    "C:/Windows/Temp",
    "C:/Users/{}/AppData/Local/Temp".format(os.getlogin())
]

# Dosya temizleme fonksiyonu
def delete_files_in_directory(directory):
    try:
        files = os.listdir(directory)
        total_files = len(files)
        for idx, filename in enumerate(files):
            file_path = os.path.join(directory, filename)
            if os.path.isdir(file_path):
                shutil.rmtree(file_path)
            else:
                os.remove(file_path)
            progress['value'] = (idx + 1) / total_files * 100  # Güncel değeri ilerleme çubuğuna aktar
            root.update_idletasks()
        print(f"{directory} içindeki dosyalar başarıyla silindi.")
    except Exception as e:
        print(f"Silme sırasında hata oluştu: {e}")

# Temizleme işlemi
def clean_up():
    for directory in temp_directories:
        if os.path.exists(directory):
            delete_files_in_directory(directory)
            log_action(f"{directory} içindeki dosyalar silindi.")
            messagebox.showinfo("Temizleme Tamamlandı", "Geçici dosyalar başarıyla silindi.")
        else:
            log_action(f"{directory} yolu bulunamadı!")
            messagebox.showwarning("Dosya Bulunamadı", f"{directory} yolu bulunamadı!")

# Yedekleme işlemi
def backup_data():
    source_dir = "C:/Users/{}/Documents".format(os.getlogin())
    backup_dir = "C:/Backup/{}".format(datetime.now().strftime("%Y-%m-%d_%H-%M-%S"))
    try:
        if not os.path.exists(backup_dir):
            os.makedirs(backup_dir)
        shutil.copytree(source_dir, backup_dir)
        messagebox.showinfo("Yedekleme Tamamlandı", f"Veri başarıyla yedeklendi: {backup_dir}")
        log_action(f"Veri başarıyla yedeklendi: {backup_dir}")
    except Exception as e:
        print(f"Yedekleme sırasında hata oluştu: {e}")
        messagebox.showerror("Yedekleme Hatası", f"Yedekleme sırasında bir hata oluştu: {e}")

# Zip ile Yedekleme
def backup_data_zip():
    source_dir = "C:/Users/{}/Documents".format(os.getlogin())
    backup_dir = "C:/Backup/{}".format(datetime.now().strftime("%Y-%m-%d_%H-%M-%S"))
    try:
        shutil.make_archive(backup_dir, 'zip', source_dir)
        messagebox.showinfo("Yedekleme Tamamlandı", f"Veri başarıyla yedeklendi: {backup_dir}.zip")
        log_action(f"Veri başarıyla yedeklendi: {backup_dir}.zip")
    except Exception as e:
        print(f"Yedekleme sırasında hata oluştu: {e}")
        messagebox.showerror("Yedekleme Hatası", f"Yedekleme sırasında bir hata oluştu: {e}")

# Kullanıcı klasör seçimi
def select_directory():
    folder_selected = filedialog.askdirectory()  # Kullanıcıya klasör seçtirme
    if folder_selected:
        print(f"Seçilen klasör: {folder_selected}")
        return folder_selected
    return None

# Yedekleme işlemi kullanıcı seçimi ile
def backup_data_user_selected():
    source_dir = select_directory()  # Kullanıcının seçtiği klasörü yedekle
    if source_dir:
        backup_dir = "C:/Backup/{}".format(datetime.now().strftime("%Y-%m-%d_%H-%M-%S"))
        shutil.copytree(source_dir, backup_dir)
        messagebox.showinfo("Yedekleme Tamamlandı", f"Veri başarıyla yedeklendi: {backup_dir}")
        log_action(f"Veri başarıyla yedeklendi: {backup_dir}")

# Zamanlanmış görevler
def job():
    clean_up()
    backup_data()

# 1 gün arayla işleme başla
schedule.every().day.at("12:00").do(job)

# Progress bar ekleme
progress = ttk.Progressbar(root, length=400, mode='determinate')
progress.pack(pady=20)

# Loglama fonksiyonu
def log_action(action):
    logging.info(action)

# Temizleme işlemi ve yedekleme işlemi başlatma (Ana iş parçacığında çalıştırma)
def start_cleanup_and_backup():
    threading.Thread(target=perform_task).start()  # Task'i ayrı bir iş parçacığında başlatıyoruz

# Gerçek işlemi başlatan fonksiyon (İş parçacığındaki ana işlem)
def perform_task():
    clean_up()
    backup_data()

# Zamanlayıcıyı sürekli çalıştırma
def run_scheduler():
    while True:
        schedule.run_pending()
        time.sleep(60)

# Ana menüdeki butonlar
start_button = Button(root, text="Yedekle ve Temizle", command=start_cleanup_and_backup)
start_button.pack(pady=20)

zip_backup_button = Button(root, text="Zip Yedekleme", command=backup_data_zip)
zip_backup_button.pack(pady=20)

custom_backup_button = Button(root, text="Kullanıcı Klasörü Yedekleme", command=backup_data_user_selected)
custom_backup_button.pack(pady=20)

# Ana pencereyi çalıştırma
root.mainloop()

# Zamanlayıcıyı sürekli çalıştırma (Arka planda)
run_scheduler()
